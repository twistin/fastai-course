# insect bites > 2022-07-07 10:08am
https://universe.roboflow.com/insect-bite-identifier-ceyst/insect-bites

Provided by a Roboflow user
License: CC BY 4.0

